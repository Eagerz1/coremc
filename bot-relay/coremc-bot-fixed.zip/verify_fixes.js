// Regression checks for the fixes applied to coremc-bot.
// Run with: node verify_fixes.js   (from the repo root)
const assert = require('assert');
const fs = require('fs');
const path = require('path');

let pass = 0;
function check(name, fn) {
  try { fn(); console.log('  PASS  ' + name); pass++; }
  catch (e) { console.log('  FAIL  ' + name + '\n          ' + e.message); process.exitCode = 1; }
}

global.cfg = JSON.parse(fs.readFileSync(path.join(__dirname, 'config.json'), 'utf8'));

// ---------------------------------------------------------------- permissions
const perms = require('./permissions');
const member = (roleIds) => ({
  roles: { cache: { has: (r) => roleIds.includes(r) } },
  permissions: { has: () => false },
});
const sr = global.cfg.staffRoleIds;

check("notes.view is no longer MEMBER", () => {
  assert.strictEqual(perms.PERM('notes.view'), 'HELPER');
});
check("a plain member can NOT view player notes any more", () => {
  assert.strictEqual(perms.can(member([]), 'notes.view'), false);
});
check("a Helper still can view player notes", () => {
  assert.strictEqual(perms.can(member([sr.helper]), 'notes.view'), true);
});
check("notes.add / notes.remove unchanged", () => {
  assert.strictEqual(perms.PERM('notes.add'), 'HELPER');
  assert.strictEqual(perms.PERM('notes.remove'), 'SR_MOD');
});

// ---------------------------------------------------------------- notes.js
const notes = require('./notes');
check("notes.js loads at all (used to throw on require)", () => {
  assert.strictEqual(typeof notes.addNote, 'function');
});
check("sanitize() still breaks @everyone", () => {
  const out = notes.sanitize('hello @everyone and @here and <@123>');
  assert.ok(!out.includes('@everyone'), 'raw @everyone survived: ' + out);
  assert.ok(!out.includes('@here'), 'raw @here survived: ' + out);
  assert.ok(out.includes('@\u200b'), 'no zero-width space inserted');
});

// ---------------------------------------------------------------- embed.js
const { brandEmbed, BRAND } = require('./embed');
check("brandEmbed() defaults to the brand colour", () => {
  assert.strictEqual(brandEmbed().data.color, BRAND.color);
});
check("brandEmbed() now honours config.embedColor (the comment always claimed it did)", () => {
  global.cfg.embedColor = 0x123456;
  assert.strictEqual(brandEmbed().data.color, 0x123456);
  delete global.cfg.embedColor;
});
check("explicit opts.color still wins over config.embedColor", () => {
  global.cfg.embedColor = 0x123456;
  assert.strictEqual(brandEmbed({ color: 0xabcdef }).data.color, 0xabcdef);
  delete global.cfg.embedColor;
});

// ---------------------------------------------------------------- giveaways.js
check("scheduleDraw() never asks setTimeout for a delay it cannot honour", () => {
  // Node caps a single timer at 2^31-1 ms (~24.8 days) and fires it *immediately*
  // past that, which drew a long giveaway the instant it was published.
  const fs2 = require('fs');
  const dir = path.join(__dirname, 'data');
  fs2.mkdirSync(dir, { recursive: true });
  const MSG = 'verify_long_giveaway';
  const store = JSON.parse(
    fs2.existsSync(path.join(dir, 'giveaways.json'))
      ? fs2.readFileSync(path.join(dir, 'giveaways.json'), 'utf8') : '{}');
  store[MSG] = {
    channelId: 'nope', guildId: 'nope', title: 'long', prize: 'long',
    winners: 1, roleReq: '', hostId: 'nope', entries: [],
    endAt: Date.now() + 720 * 3600_000,   // 30 days: the wizard's own maximum
    announced: false,
  };
  fs2.writeFileSync(path.join(dir, 'giveaways.json'), JSON.stringify(store, null, 2));

  const captured = [];
  const realSetTimeout = global.setTimeout;
  global.setTimeout = (fn, ms) => { captured.push(ms); return { unref() {} }; };
  let gw;
  try {
    delete require.cache[require.resolve('./giveaways')];
    gw = require('./giveaways');
    captured.length = 0;
    gw.scheduleDraw(MSG);
  } finally {
    global.setTimeout = realSetTimeout;
  }
  assert.ok(captured.length > 0, 'scheduleDraw() scheduled no timer at all');
  for (const ms of captured) {
    assert.ok(ms <= 2 ** 31 - 1, 'timer scheduled for ' + ms + ' ms, over the 2^31-1 cap');
  }
  assert.ok(
    captured.includes(2 ** 31 - 1),
    'expected a re-arm at the cap for a 30-day giveaway, got ' + JSON.stringify(captured));
});

check("a short giveaway is still scheduled for its real duration", () => {
  const fs2 = require('fs');
  const dir = path.join(__dirname, 'data');
  const MSG = 'verify_short_giveaway';
  const store = JSON.parse(fs2.readFileSync(path.join(dir, 'giveaways.json'), 'utf8'));
  store[MSG] = Object.assign({}, store['verify_long_giveaway'],
    { title: 'short', endAt: Date.now() + 60_000 });
  fs2.writeFileSync(path.join(dir, 'giveaways.json'), JSON.stringify(store, null, 2));

  const captured = [];
  const realSetTimeout = global.setTimeout;
  global.setTimeout = (fn, ms) => { captured.push(ms); return { unref() {} }; };
  try {
    delete require.cache[require.resolve('./giveaways')];
    require('./giveaways').scheduleDraw(MSG);
  } finally {
    global.setTimeout = realSetTimeout;
  }
  assert.strictEqual(captured.length, 1);
  assert.ok(captured[0] > 50_000 && captured[0] <= 60_000, 'unexpected delay ' + captured[0]);
});

// ---------------------------------------------------------------- index.js
const idx = fs.readFileSync(path.join(__dirname, 'index.js'), 'utf8');
check("index.js parses (it was 31 collapsed lines with a SyntaxError)", () => {
  assert.ok(idx.length > 40000);
  assert.ok(!/async async/.test(idx), 'quadruple `async` keyword still present');
});
check("the 'player-notes-channel-id' placeholder is gone", () => {
  assert.ok(!idx.includes('player-notes-channel-id'));
  assert.ok(idx.includes('config.notesChannelId'));
});
check("notesChannelId is in the loadConfig() defaults", () => {
  assert.ok(/notesChannelId: ""|notesChannelId: ''/.test(idx));
});
check("resolveCloseRequest() approve path is reachable again", () => {
  const i = idx.indexOf('async function resolveCloseRequest');
  const body = idx.slice(i, idx.indexOf('async function completeStaffClose'));
  // the spurious wrapper put every `await interaction.update(...)` approve step
  // inside `if (!approved)`, so approving a close request did nothing at all.
  const approveIdx = body.indexOf('Close request approved by');
  const lastDeny = body.lastIndexOf('denied the close request');
  assert.ok(approveIdx > lastDeny, 'approve branch still nested under the deny branch');
  assert.strictEqual(
    body.slice(0, approveIdx).split('if (!approved)').length - 1, 1,
    'expected exactly one `if (!approved)` guard, found ' +
      (body.slice(0, approveIdx).split('if (!approved)').length - 1));
});
check("partner_verify buttons are still unrouted (documented, not silently changed)", () => {
  assert.strictEqual((idx.match(/partner_verify_/g) || []).length, 3);
});

console.log('\n' + pass + ' checks passed' + (process.exitCode ? ' (with failures)' : ''));
